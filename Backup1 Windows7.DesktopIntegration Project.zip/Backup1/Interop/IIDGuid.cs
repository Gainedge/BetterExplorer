// Copyright (c) Microsoft Corporation.  All rights reserved.

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Windows7.DesktopIntegration.Interop
{
    internal class IIDGuid
    {
        internal const string IShellLibrary = "11a66efa-382e-451a-9234-1e0e12ef3085";
    }

}