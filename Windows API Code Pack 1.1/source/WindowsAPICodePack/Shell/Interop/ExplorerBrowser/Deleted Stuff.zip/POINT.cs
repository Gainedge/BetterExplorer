﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Microsoft.WindowsAPICodePack.Controls {
	public struct POINT {
		public long x;
		public long y;
	}
}
