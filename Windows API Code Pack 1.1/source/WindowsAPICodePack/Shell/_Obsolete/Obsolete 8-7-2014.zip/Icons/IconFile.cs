﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;

namespace _Obsolete.Microsoft.WindowsAPICodePack.Shell {
	public class IconFile {
		public Icon Icon { get; set; }
		public int Index { get; set; }
	}
}
